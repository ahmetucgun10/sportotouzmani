# ⚽ SportAgent AI — Çoklu Ajan Spor Analiz Platformu

Yapay zeka destekli **6 uzman ajandan** oluşan bir ajan ordusu; internet genelinde araştırma
yaparak sakatlıkları, cezaları, form durumunu, güncel haberleri ve tarihsel karşılaşmaları analiz
eder ve **hangi takımın kazanabileceğine dair kapsamlı bir tahmin** üretir.

> 🌐 **Tam kurulum (canlı) modunda çalışır.** Ajan ordusu gerçek internet araştırması yapar ve AI
> ile analiz üretir. Bunun için `OPENAI_API_KEY` ve `TAVILY_API_KEY` anahtarları **zorunludur**.

---

## 🤖 Ajan Ordusu (18 Uzman Ajan — 3 Katmanlı Doğruluk Motoru)

**1. Katman — Takım & İleri İstatistik Ajanları** (her iki takım için ayrı çalışır):

| Ajan | Görevi |
|------|--------|
| 📈 xG & İleri İstatistik Ajanı | Beklenen gol (xG/xGA), şut kalitesi ve şans faktörü |
| 🏥 Sakatlık & Ceza Ajanı | As kadro eksikleri ve 10 üzerinden etki skoru |
| 📊 Form Analiz Ajanı | Son 5 maç formu ve oynanan rakiplerin zorluk derecesi |
| 👔 Teknik Direktör & Taktik Ajanı | Diziliş, pres şiddeti ve oyun planı |
| ⭐ Yıldız Oyuncu Ajanı | Skorer ve kilit oyuncuların güncel formu |
| 🔁 Transfer & Kadro Derinliği Ajanı | Yedek kulübesi hamle gücü ve kadro kalitesi |
| 📰 Güncel Haberler Ajanı | Son dakika kamp ve kulüp gelişmeleri |
| 📱 Sosyal Medya & Baskı Ajanı | Taraftar desteği / stres baskısı analizi |
| 💬 Uzman Yorum Ajanı | Güçlü/zayıf yönler + objektif performans notu |

**2. Katman — Maç Dinamikleri & Keskin Piyasa Ajanları:**

| Ajan | Görevi |
|------|--------|
| 🏟️ İç / Dış Saha Split Uzmanı | Ev sahibinin iç saha vs deplasmanın dış saha karnesi |
| ⏱️ Fikstür Yorgunluğu & Rotasyon Ajanı | Dinlenme günleri, kupa/Avrupa yorgunluğu ve rotasyon riski |
| 🧩 Muhtemel 11 & Duran Top Ajanı | Beklenen 11'ler, mevki eşleşmeleri ve korner/frikik zaafları |
| 📉 Keskin Oran & Piyasa Hareketleri Ajanı | İma edilen olasılıklar, oran düşüşleri ve tuzak oran sinyali |
| 🔥 Motivasyon & Hedef Ajanı | Şampiyonluk/Avrupa/küme düşme puan ihtiyacı |
| ⚔️ Tarihsel H2H Ajanı | Yakın dönem karşılaşma ve gol paternleri |
| 🌦️ Hava Durumu & Saha Zemin Ajanı | Yağış, rüzgar ve zemin koşulları etkisi |
| 🟨 Hakem & Disiplin Ajanı | Hakemin kart/penaltı ortalaması ve tempo etkisi |

**3. Katman — Çapraz Doğrulama & Olasılık Kalibrasyon Komitesi:**

| Ajan | Görevi |
|------|--------|
| 🤖 Orkestrasyon Ajanı | Tüm 3 katmanı ve eşzamanlılık kuyruğunu yönetir |
| 📐 Kantitatif & Poisson Model Ajanı | Beklenen gol (λ) ve %1 / %X / %2 olasılık dağılımını hesaplar |
| ⚖️ Şeytanın Avukatı & Tuzak Denetçisi | Popüler takım yanlılığını kırar, sürpriz/tuzak riskini denetler |
| 🎯 Tahmin Komutanı (Ensemble) | Tüm verileri ağırlıklı sentezleyip kalibre edilmiş final tahmini üretir |

---

## 🚀 Netlify'a Deploy (Adım Adım)

### Yöntem A — GitHub üzerinden (Önerilen)

1. **Projeyi GitHub'a yükleyin**
   ```bash
   git init
   git add .
   git commit -m "SportAgent AI"
   git branch -M main
   git remote add origin https://github.com/KULLANICI_ADIN/sportagent-ai.git
   git push -u origin main
   ```

2. **Netlify'da yeni site oluşturun**
   - [app.netlify.com](https://app.netlify.com) → **Add new site** → **Import an existing project**
   - GitHub reponuzu seçin
   - Netlify Next.js'i otomatik algılar. Ayarları olduğu gibi bırakın:
     - **Build command:** `npm run build`
     - **Publish directory:** `.next`
   - **Deploy** butonuna basın 🎉

3. **Ortam değişkenlerini ekleyin (ZORUNLU)**
   - Site açıldıktan sonra **Site settings → Environment variables** bölümüne gidin:
     | Değişken | Açıklama | Gerekli mi? |
     |----------|----------|-------------|
     | `OPENAI_API_KEY` | AI analizleri için | ✅ Zorunlu |
     | `TAVILY_API_KEY` | Gerçek internet araştırması için | ✅ Zorunlu |
     | `DATABASE_URL` | Analiz geçmişini kaydetmek için | ⬜ Opsiyonel |
   - Değişkenleri ekledikten sonra **Deploys → Trigger deploy → Deploy site** ile yeniden yayınlayın.
   - `OPENAI_API_KEY` veya `TAVILY_API_KEY` eksikse arayüzde "Kurulum Gerekli" uyarısı çıkar ve
     analiz başlatılamaz.

### Yöntem B — Netlify CLI ile

```bash
npm install -g netlify-cli
netlify login
netlify init          # yeni site oluştur
netlify deploy --build --prod
```

---

## 🔑 API Anahtarları Nereden Alınır?

| Servis | Link | Ücretsiz? |
|--------|------|-----------|
| OpenAI | https://platform.openai.com/api-keys | Kullandıkça öde |
| Tavily | https://app.tavily.com | ✅ Ücretsiz katman |
| Neon (PostgreSQL) | https://neon.tech | ✅ Ücretsiz |
| Supabase (PostgreSQL) | https://supabase.com | ✅ Ücretsiz |

> **Not:** `OPENAI_API_KEY` ve `TAVILY_API_KEY` **zorunludur** — bunlar olmadan analiz başlatılamaz
> (arayüzde "Kurulum Gerekli" uyarısı gösterilir).

---

## 🗄️ Veritabanı (Opsiyonel)

Analiz geçmişini saklamak isterseniz bir bulut PostgreSQL bağlayın:

1. [Neon](https://neon.tech) veya [Supabase](https://supabase.com)'de ücretsiz bir veritabanı açın.
2. Bağlantı dizesini (connection string) kopyalayın.
3. Netlify'da `DATABASE_URL` ortam değişkenine yapıştırın.
4. Tabloları oluşturmak için (yerel makinenizde `.env`'e `DATABASE_URL` ekleyip):
   ```bash
   npx drizzle-kit push
   ```

`DATABASE_URL` yoksa uygulama **"veritabanısız mod"** ile çalışır: analizler üretilir ama kaydedilmez.

---

## 💻 Yerel Geliştirme

```bash
npm install
cp .env.example .env      # değerleri doldurun (opsiyonel)
npm run dev               # http://localhost:3000
```

Production build test:
```bash
npm run build
npm run start
```

---

## 🛠️ Teknoloji Stack

- **Framework:** Next.js 16 (App Router) + React 19
- **Stil:** Tailwind CSS
- **AI:** OpenAI (GPT-4o-mini)
- **Web Araştırma:** Tavily API
- **Veritabanı:** PostgreSQL + Drizzle ORM (opsiyonel)
- **Deploy:** Netlify (`@netlify/plugin-nextjs`)
- **Streaming:** Server-Sent Events (SSE) ile canlı ajan takibi

---

## ⚠️ Yasal Uyarı

Bu platform yalnızca bilgi ve eğlence amaçlıdır. Üretilen tahminler **bahis tavsiyesi değildir**.
Kararlarınızdan siz sorumlusunuz.
