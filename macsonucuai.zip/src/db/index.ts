import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

// Database is optional. On serverless hosts (Netlify) without a DATABASE_URL,
// the app runs in a "no-database" mode: analyses are computed and streamed,
// but not persisted. Set DATABASE_URL to enable history/persistence.
export const hasDatabase = !!databaseUrl;

let poolInstance: Pool | null = null;

if (databaseUrl) {
  poolInstance =
    globalForDb.__arenaNextJsPostgresqlPool ??
    new Pool({
      connectionString: databaseUrl,
      // Cloud Postgres (Neon/Supabase) often requires SSL.
      ssl: /sslmode=require|neon\.tech|supabase/.test(databaseUrl)
        ? { rejectUnauthorized: false }
        : undefined,
    });

  if (process.env.NODE_ENV !== "production") {
    globalForDb.__arenaNextJsPostgresqlPool = poolInstance;
  }
}

export const pool = poolInstance;

// `db` is only usable when a database is configured. Guard usages with
// `hasDatabase` before calling into it.
export const db = poolInstance ? drizzle(poolInstance) : (null as unknown as ReturnType<typeof drizzle>);
